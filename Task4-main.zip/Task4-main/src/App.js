
import Dummydata from './Dummydata';

function App() {
  return (
    <div>
      <Dummydata/>
    </div>
  );
}

export default App;